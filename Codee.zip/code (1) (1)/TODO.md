# Project outcomes

- [x] Build an English-language responsive journal website using only HTML, CSS and JavaScript.
  - Include semantic, connected Home, About and Article pages.
  - Keep the visual language restrained and professional, with Scopus-style journal typography, spacing and hierarchy.

- [x] Create the Home page for The Global Journal of Management, Economics and Social Sciences.
  - State that the journal was established in 2021, is published twice a year, is subscription-based and not open access, and charges publication fees.
  - Keep the page focused on the journal itself rather than displaying the article.

- [x] Create the About page.
  - Present a credible editorial profile, scope, mission, peer-review approach, publication ethics, access model and author information in English.

- [x] Create the published Article page.
  - Show author Ilham Madi.
  - Show the exact title: “Analyzing the Determinants of Competitiveness of Maritime Economic Corridors: An Analytical Study of Infrastructure, Services, and Governance”.
  - Show the abstract and organized references.
  - Show submitted 23 August 2025, received 13 October 2025, published 28 December 2025, Volume 13, Issue 2.
  - Include realistic article navigation and citation/share interface elements without claiming unavailable publishing functions.
  - Keep the article on its own dedicated page, with navigation from that page to Home, About and author information.

- [x] Provide polished responsive behavior for mobile and desktop, including a mobile navigation toggle, article metadata layout, article tools, and accessible interactive states.

- [x] Add a publication archive and issue navigation.
  - Provide archive years 2026, 2025, 2024, 2023, 2022 and 2021 with twice-yearly issue rows.
  - Make Volume 13, Issue 2, December 2025 open an issue contents page.
  - Show the requested article and Ilham Madi in the issue contents, with a link to the complete article page.

- [x] Add Author Guidelines and Publishing Policy.
  - Cover publication policy, manuscript preparation, peer-review requirements, research ethics and a submission checklist.
  - Link the new page from the shared navigation and footer.

- [x] Add the supplied official journal cover to the Home page in a responsive, prominent journal-identity placement.
