export default { logoUrl: "https://www.gstatic.com/images/branding/product/1x/googleg_32dp.png" };
