document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-current-year]').forEach((node) => {
    node.textContent = new Date().getFullYear();
  });

  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#site-nav');
  if (menu && nav) {
    menu.addEventListener('click', () => {
      const open = menu.getAttribute('aria-expanded') === 'true';
      menu.setAttribute('aria-expanded', String(!open));
      nav.classList.toggle('is-open', !open);
    });
    nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
      menu.setAttribute('aria-expanded', 'false');
      nav.classList.remove('is-open');
    }));
  }

  const status = document.querySelector('.tool-status');
  const articleTitle = 'Analyzing the Determinants of Competitiveness of Maritime Economic Corridors: An Analytical Study of Infrastructure, Services, and Governance';
  const citation = `Madi, Ilham. “${articleTitle}.” The Global Journal of Management, Economics and Social Sciences, vol. 13, no. 2, 28 December 2025.`;
  const showStatus = (message) => {
    if (!status) return;
    status.textContent = message;
    window.setTimeout(() => { status.textContent = ''; }, 3500);
  };

  document.querySelectorAll('[data-action="cite"]').forEach((button) => button.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(citation);
      showStatus('Citation copied');
    } catch {
      showStatus('Citation ready to copy');
    }
  }));

  document.querySelectorAll('[data-action="share"]').forEach((button) => button.addEventListener('click', async () => {
    const shareData = { title: articleTitle, text: citation, url: window.location.href };
    try {
      if (navigator.share) await navigator.share(shareData);
      else { await navigator.clipboard.writeText(window.location.href); showStatus('Article link copied'); }
    } catch (error) {
      if (error && error.name !== 'AbortError') showStatus('Article link ready to share');
    }
  }));
});
