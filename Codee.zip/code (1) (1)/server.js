const http = require('http');
const fs = require('fs');
const path = require('path');

const root = __dirname;
const port = Number(process.env.PORT || 3000);
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function safePath(urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  if (decoded === '/manus-routes.json') return path.join(root, 'public', 'manus-routes.json');
  const requested = decoded === '/' ? '/index.html' : decoded;
  const resolved = path.normalize(path.join(root, requested));
  return resolved.startsWith(root) ? resolved : path.join(root, 'index.html');
}

const server = http.createServer((req, res) => {
  const filePath = safePath(req.url || '/');
  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': mime[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    res.end(data);
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`GJMESS journal running on http://0.0.0.0:${port}`);
});
